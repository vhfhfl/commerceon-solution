let LayerData = [];
const MarkupUtil = {};

/**
 *
 */
MarkupUtil.attachInfoBox = function () {
  const html = `
  <a href="../layout/blank.html?page=사이트맵" id="markupInfoBox" style="cursor:pointer; text-align:center; font-size:10px; color:#1cffe3; border-radius:4px; padding:4px 8px; z-index:999999; position:fixed; top:0px; left:50%; transform:translateX(-50%); background-color:rgba(0,0,0,.5);">
      <span class="width"></span> x <span class="height"></span>
      <span class="hidden sm:inline-block md:hidden text-[yellow]">sm : 640 ~</span>
      <span class="hidden md:inline-block lg:hidden text-[yellow]">md : 768 ~</span>
      <span class="hidden lg:inline-block xl:hidden text-[yellow]">lg : 1024 ~</span>
      <span class="hidden xl:inline-block text-[yellow]">xl : 1280 ~</span>
  </a>
  `;
  document.body.insertAdjacentHTML('afterbegin', html);
  
  const el_markupInfoBox = document.getElementById('markupInfoBox');
  const el_wid = el_markupInfoBox.querySelector('.width');
  const el_hei = el_markupInfoBox.querySelector('.height');
  
  function resizeListener() {
    el_wid.innerHTML = window.innerWidth;
    el_hei.innerHTML = window.innerHeight;
  }
  resizeListener();
  window.addEventListener("resize", resizeListener);
}

/**
 * 동기방식으로 .html 파일 include
 * @param path
 * @constructor
 */
MarkupUtil.include = function (path) {
  const $me = document.currentScript;
  
  let htmlString;
  
  const xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    /*
    readyState
    0	UNSENT	Client has been created. open() not called yet.
    1	OPENED	open() has been called.
    2	HEADERS_RECEIVED	send() has been called, and headers and status are available.
    3	LOADING	Downloading; responseText holds partial data.
    4	DONE	The operation is complete.
    */
    if (this.readyState == 4) {
      if (this.status == 200) {
        // success
        htmlString = this.responseText;
      } else {
        // error
        const msg = '404 Not Found';
        console.log("path : ", path);
        console.log(`%c${msg}%c${path}`, 'font-family:D2Coding; border:1px solid black; background:red; color:white; padding:10px; font-size:14px;', 'font-family:D2Coding; background-color:black; border:1px solid black; border-left:none; padding:10px; color:yellow; font-size:14px;');
        // MarkupUtil.include('../pages/기타/404.html');
        htmlString = path;
      }
      
    }
  };
  xhttp.open('GET', path, false);
  xhttp.send();
  /*
  console.log("=============================================");
  console.log(`🍒 include path : ${path} 🍒`);
  console.log(htmlString);
  console.log("=============================================");
   */
  if (htmlString) document.write(htmlString);
  
  $me.remove();
}

MarkupUtil.includePage = function () {
  
  const page = Params.page;
  MarkupUtil.include(`../pages/${page}.html`);
}

/**
 * GET 파라메터 유틸
 * @type {{}}
 */
const Params = function () {
  // This function is anonymous, is executed immediately and
  // the return value is assigned to Params!
  let query_string = {};
  let query = window.location.search.substring(1);
  let vars = query.split("&");
  for (let i = 0; i < vars.length; i++) {
    let pair = vars[i].split("=");
    // If first entry with this name
    if (typeof query_string[pair[0]] === "undefined") {
      query_string[pair[0]] = decodeURIComponent(pair[1]);
      // If second entry with this name
    } else if (typeof query_string[pair[0]] === "string") {
      let arr = [query_string[pair[0]], decodeURIComponent(pair[1])];
      query_string[pair[0]] = arr;
      // If third or later entry with this name
    } else {
      query_string[pair[0]].push(decodeURIComponent(pair[1]));
    }
  }
  return query_string;
}();

/**
 * document ready
 */
document.addEventListener('readystatechange', () => {
  if (document.readyState === 'interactive') {
    MarkupUtil.attachInfoBox();
  }
});








