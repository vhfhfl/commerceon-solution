{
  /**
   * TAB-UI 컨트롤
   * @param el_tab_btn
   * @constructor
   */
  function ACTIVE_TAB(el_tab_btn) {
    
    const tab_btn_list = el_tab_btn.parentElement.querySelectorAll(`[data-tab-key]`);
    tab_btn_list.forEach((tab_btn, idx) => {
      tab_btn.classList.remove('on');
    });
    
    const tab_key = el_tab_btn.getAttribute(`data-tab-key`);
    console.log("tab_key == ", tab_key);
    el_tab_btn.classList.add('on');
    
    const el_tab_child = document.querySelector(`[data-tab-child="${tab_key}"]`);
    if (!el_tab_child) return;
    
    const tab_child_list = el_tab_child.parentElement.querySelectorAll(`[data-tab-child]`);
    tab_child_list.forEach((tab_child, idx) => {
      tab_child.classList.remove('on');
    });
    
    el_tab_child.classList.add('on');
    
  }
}

{
  /**
   * TOGGLE-BTN 컨트롤
   * @param el_toggle_btn
   * @constructor
   */
  function TOGGLE_BTN(el_toggle_btn){
    const toggle_key = el_toggle_btn.getAttribute(`data-toggle-key`);
    
    const toggle_child_list = document.querySelectorAll(`[data-toggle-child="${toggle_key}"]`);
    if(!toggle_child_list) return;
    
    toggle_child_list.forEach((el_toggle_child, idx) => {
      el_toggle_child.classList.toggle('ACTIVE');
    });
  }
}