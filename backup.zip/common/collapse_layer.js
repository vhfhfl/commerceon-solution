/**
 * ./layer 폴더가 변경되는것을 감지하여 layer.html 을 빌드한다.
 * @type {string}
 */
const path = './common/layer';
const fs = require('fs');

fs.watch(path, function(){
  collapse();
});

collapse();

function collapse(){
  let str = '<div id="layerWrapper">';
  const filelist = fs.readdirSync(path);
  for (var i in filelist) {
    const filename = filelist[i];
    const filePath = path + '/' + filename;
    
    let fileContent = fs.readFileSync(filePath, 'utf-8');
    // 줄바꿈 제거
    fileContent = fileContent.replace(/\n/g, "");
    
    str += fileContent;
  }
  str += '</div>';
  str += '<script>';
  
  for (var i in filelist) {
    const filename = filelist[i];
    str += `LayerData.push('${filename}');`
  }
  str += '</script>';

// console.log("str : ", str);
  
  const contents = str;
  const outputPath = './common/layer.html';
  fs.writeFile(outputPath, contents, 'utf8', function (err) {
    console.log(`${outputPath} created!`);
  });
}




